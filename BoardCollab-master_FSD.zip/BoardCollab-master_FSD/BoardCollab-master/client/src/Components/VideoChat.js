import React, {useState, useEffect, useRef} from 'react'

function VideoChat() {
  
  return (  
    <div>

    </div>
  )
}

export default VideoChat
