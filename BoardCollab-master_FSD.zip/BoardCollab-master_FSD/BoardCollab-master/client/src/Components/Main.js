import React from 'react'
import Whiteboard from './Whiteboard'
import VideoChat from './VideoChat'
import Chat from './Chat'
import '../styles/main.css'

function App() {
  return (
    <div>
      {/* <Chat/> */}
      <Whiteboard />
    </div>
  )
}

export default App
